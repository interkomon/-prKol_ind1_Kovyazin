﻿
namespace Collection_Queue8_Kovyazin
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.SelectFilebutton1 = new System.Windows.Forms.Button();
            this.Vivod = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SelectFilebutton1
            // 
            this.SelectFilebutton1.Location = new System.Drawing.Point(21, 203);
            this.SelectFilebutton1.Name = "SelectFilebutton1";
            this.SelectFilebutton1.Size = new System.Drawing.Size(147, 23);
            this.SelectFilebutton1.TabIndex = 0;
            this.SelectFilebutton1.Text = "Выбрать файл";
            this.SelectFilebutton1.UseVisualStyleBackColor = true;
            this.SelectFilebutton1.Click += new System.EventHandler(this.SelectFilebutton1_Click);
            // 
            // Vivod
            // 
            this.Vivod.AutoSize = true;
            this.Vivod.Location = new System.Drawing.Point(63, 95);
            this.Vivod.Name = "Vivod";
            this.Vivod.Size = new System.Drawing.Size(0, 13);
            this.Vivod.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(544, 284);
            this.Controls.Add(this.Vivod);
            this.Controls.Add(this.SelectFilebutton1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SelectFilebutton1;
        private System.Windows.Forms.Label Vivod;
    }
}

