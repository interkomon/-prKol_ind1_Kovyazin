﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Collection_Queue8_Kovyazin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SelectFilebutton1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if(openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDialog.FileName;
                RabFile(fileName);
                
            }
            
        }

        private void RabFile(string fileName)
        {
            Queue<string> young30 = new Queue<string>();
            Queue<string> ostOld = new Queue<string>();

            StreamReader sr = new StreamReader(fileName);
            string line;
            while((line = sr.ReadLine())!= null)
            {
                string[] parts = line.Split(',');
                string fullName = $"{parts[0]}{parts[1]}{parts[2]}";
                int age = int.Parse(parts[4]);
                if (age < 30)
                {
                   
                    young30.Enqueue(line);
                }
                else
                {
                   
                    ostOld.Enqueue(line);
                }
            }
            if(fileName.Length == 0)
            {
                MessageBox.Show("Ошибка", "");
            }

            string result = "";
            while(young30.Count > 0)
            {
                result += young30.Dequeue() + Environment.NewLine;
            }
                while(ostOld.Count > 0)
            {
                result += ostOld.Dequeue() + Environment.NewLine;
            }
            Vivod.Text = result;
            
            




        }
    }
}
